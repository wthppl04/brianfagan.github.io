# VendingMachine

Group project with @weinbpa during GCU Java certificate program, CST-135 course.
Built a customer-facing vending machine application with a back-end for
machine administration. Used agile principles and completed the app from scratch
in less than 10 days. Turning over to a new development team for the next course.
